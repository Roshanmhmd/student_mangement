## About Student Management

We have list our student and her mark in different terms.

Using for 2 table to working this system. (Database .sql backup are included in our Gitup files (Name - student_management.sql))



