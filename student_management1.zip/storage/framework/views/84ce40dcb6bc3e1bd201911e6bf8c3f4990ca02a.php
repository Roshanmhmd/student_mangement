<?php $__env->startSection('content'); ?>

<div class="row subheading">
    <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
        <div class="card">
        <div class="card-header">
            <div class="float-left col-md-8">
                <div class="card-title">Student Lists</div>
            </div>
            <div class="float-left col-md-4">
                <div class="float-right">
                <a href="<?php echo url('/student/create'); ?>" class="btn btn-sm" title="Create Student">Create</a>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>

<div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
  <div class="card bodycard">
    <div class="card-body pt-4 overflow-hidden">
      <div class="table-card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="studentTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Reporting Teacher</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $getStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($student->id); ?></td>
                    <td><?php echo e($student->student_name); ?></td>
                    <td><?php echo e($student->student_age); ?></td>
                    <td><?php echo e($student->gender); ?></td>
                    <td><?php echo e($student->reporting_teacher); ?></td>
                    <td class="text-center">
                      <a href="student/<?php echo base64_encode(trim($student->id)); ?>/edit" class="btn btn-sm" title="Edit">Edit</a>
                      <button data-id="<?php echo base64_encode(trim($student->id)); ?>" class="btn btn-sm delete_student" title="Delete" data-toggle="modal" data-target="#openDeleteModal">Delete</button>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="openDeleteModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Are you sure?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Do you really want to delete these records?</p>
      </div>
      <div class="modal-footer">
        <form action="<?php echo url('/student/'); ?>" method="POST" id="deleteStudent" data-url="<?php echo url('/student/'); ?>">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Delete</button>
        </form>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\student_management\resources\views/student/index.blade.php ENDPATH**/ ?>