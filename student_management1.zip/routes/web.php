<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
// Auth::routes();

Route::get('/', 'App\Http\Controllers\StudentController@index');
Route::resource('student', 'App\Http\Controllers\StudentController');
Route::resource('marks', 'App\Http\Controllers\StudentMarksController');

Route::get('/clear-cache', function () {
    Artisan::call('route:clear');
    echo "Route cache cleared!";
    Artisan::call('cache:clear');
    echo "<br>Cache cleared successfully.";
    Artisan::call('config:clear');
    echo "<br>Configuration cache cleared!";
    Artisan::call('view:clear');
    echo "<br>Compiled views cleared!";
    Artisan::call('config:cache');
    echo "<br>Configuration cache cleared!";
    echo "<br>Configuration cached successfully!";
    exit;
});
