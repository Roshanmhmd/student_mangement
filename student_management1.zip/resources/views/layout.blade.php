<!doctype html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="Cache-Control" content="no-cache" />
        <title>Student Management</title>
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
        <link href="{{ asset('css/jquery.dataTables.min.css') }}" rel="stylesheet">
        <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    </head>
    <body class="app">
        <div class="app-content new-app-content">

        <div class="row">
            <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
                <div class="card">
                <div class="card-header">
                    <div class="float-left col-md-8">
                        <div class="card-title">Student Management</div>
                    </div>
                    <div class="float-left col-md-4">
                        <div class="float-right">
                        <a href="{!! url('/'); !!}" class="btn btn-sm" title="Student">Student</a>
                        <a href="{!! url('/marks'); !!}" class="btn btn-sm" title="Student Marks">Student Marks</a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        @yield('content') 
        </div>
        <script src="{{ asset('js/jquery.js') }}"></script>
        <script src="{{ asset('js/bootstrap.min.js') }}"></script>
        <script src="{{ asset('js/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('js/script.js') }}"></script>
    </body>
</html>