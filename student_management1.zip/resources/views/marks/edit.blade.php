@extends('layout')

@section('content')

<div class="row subheading">
    <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
        <div class="card">
        <div class="card-header">
            <div class="float-left col-md-8">
                <div class="card-title">Marks List</div>
            </div>
            <div class="float-left col-md-4">
                <div class="float-right">
                <a href="{!! url('/marks'); !!}" class="btn btn-sm" title="Back to Marks List">Back</a>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>

<div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
  <div class="card bodycard">
    <div class="card-body pt-4 overflow-hidden">
    <form action="{!! url('/marks/'.$encId); !!}" method="post" enctype="multipart/form-data">
        {{method_field('PATCH')}}
        @csrf
        <div class="form-group">
            <label for="student_id">Student</label>
            <select class="form-control" id="student_id" name="student_id">
                <option value="">Select</option>
                @foreach($getStudents as $student)
                    <option value="{{ $student->id }}" {{ ( $data->student_id  == $student->id) ? 'selected="selected"' : " " }}>{{ $student->student_name }}</option>
                @endforeach
            </select>
            @error('student_id')
            <div class="form-error">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="term">Term</label>
            <select class="form-control" id="term" name="term">
                <option value="">Select</option>
                <option value="One"  {{ ( $data->term  == 'One') ? 'selected="selected"' : " " }}>One</option>
                <option value="Two"  {{ ( $data->term  == 'Two') ? 'selected="selected"' : " " }}>Two</option>
            </select>
            @error('term')
                <div class="form-error">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="maths_mark">Maths</label>
            <input type="text" class="form-control" id="maths_mark" name="maths_mark" placeholder="" value="{{ $data->maths_mark }}">
            @error('maths_mark')
            <div class="form-error">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="science_mark">Science</label>
            <input type="text" class="form-control" id="science_mark" name="science_mark" placeholder="" value="{{ $data->science_mark }}">
            @error('science_mark')
            <div class="form-error">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="history_mark">History</label>
            <input type="text" class="form-control" id="history_mark" name="history_mark" placeholder="" value="{{ $data->history_mark }}">
            @error('history_mark')
            <div class="form-error">{{ $message }}</div>
            @enderror
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    </div>
  </div>
</div>
@endsection 