@extends('layout')

@section('content')

<div class="row subheading">
    <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
        <div class="card">
        <div class="card-header">
            <div class="float-left col-md-8">
                <div class="card-title">Student Lists</div>
            </div>
            <div class="float-left col-md-4">
                <div class="float-right">
                <a href="{!! url('/'); !!}" class="btn btn-sm" title="Back to Student List">Back</a>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>

<div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
  <div class="card bodycard">
    <div class="card-body pt-4 overflow-hidden">
    <form action="{!! url('/student/'.$encId); !!}" method="post" enctype="multipart/form-data">
        {{method_field('PATCH')}}
        @csrf
        <div class="form-group">
            <label for="student_name">Student Name</label>
            <input type="text" class="form-control" id="student_name" name="student_name" placeholder="" value="{{ $data->student_name }}">
            @error('student_name')
            <div class="form-error">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="age">Age</label>
            <input type="text" class="form-control" id="age" name="age" placeholder="" value="{{ $data->age }}">
            @error('age')
            <div class="form-error">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="gender">Gender</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" id="gender1" value="M" {{ ( $data->gender  == 'M') ? 'checked="checked"' : " " }}>
                <label class="form-check-label" for="gender1">
                    Male
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" id="gender2" value="F" {{ ( $data->gender  == 'F') ? 'checked="checked"' : " " }}>
                <label class="form-check-label" for="gender2">
                    Female
                </label>
            </div>
        </div>
        <div class="form-group">
            <label for="reporting_teacher">Reporting Teacher</label>
            <select class="form-control" id="reporting_teacher" name="reporting_teacher">
                <option value="">Select</option>
                <option value="Katie" {{ ( $data->reporting_teacher  == 'Katie') ? 'selected="selected"' : " " }}>Katie</option>
                <option value="Max" {{ ( $data->reporting_teacher  == 'Max') ? 'selected="selected"' : " " }}>Max</option>
            </select>
            @error('reporting_teacher')
                <div class="form-error">{{ $message }}</div>
            @enderror
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    </div>
  </div>
</div>
@endsection 