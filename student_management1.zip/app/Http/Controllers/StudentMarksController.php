<?php

namespace App\Http\Controllers;

use App\Models\sms_student_marks;
use App\Models\sms_student_details;
use Illuminate\Http\Request;
use DB;

class StudentMarksController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $getMarks = DB::table('sms_student_marks')
        ->join('sms_student_details','sms_student_details.id','sms_student_marks.student_id')
        ->select('sms_student_marks.*','sms_student_details.student_name')
        ->get();
        return view('marks/index',compact('getMarks'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $getStudents = sms_student_details::get();
        return view('marks/create',compact('getStudents'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $postData = $request->all();
        $request->validate([
            'student_id' 		=> 'required',
            'student_id' 		=> 'unique:sms_student_marks,student_id',
            'term' 		=> 'required',
            'maths_mark' => 'required',
            'science_mark' => 'required',
            'history_mark' => 'required',
        ], [
            'student_id.required' 		 => 'Please select any student.',
            'student_id.unique' 		 => 'Chosen student already selected.',
            'term.required' 	 => 'Please select any term.',
            'maths_mark.required' => 'Please enter maths mark.',
            'science_mark.required' => 'Please enter science mark.',
            'history_mark.required' => 'Please enter history mark.',
        ]);

        $marks = new sms_student_marks;

        $marks->student_id 		= $postData['student_id'];
        $marks->term 		= $postData['term'];
        $marks->maths_mark 		= $postData['maths_mark'];
        $marks->science_mark 		= $postData['science_mark'];
        $marks->history_mark 		= $postData['history_mark'];

        $marks->created_date 		= date('Y-m-d h:i:s');
        $marks->modified_date 		= date('Y-m-d h:i:s');

        if($marks->save()){
			\Session::flash('success', 'Marks created successfully.' );
		}else{
			\Session::flash('failure', 'Unable to create mark.' );
		}		
		return redirect(url('/marks'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\sms_student_marks  $sms_student_marks
     * @return \Illuminate\Http\Response
     */
    public function show(sms_student_marks $sms_student_marks)
    {
        // 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\sms_student_marks  $sms_student_marks
     * @return \Illuminate\Http\Response
     */
    public function edit($id,sms_student_marks $sms_student_marks,Request $request)
    {
        $encId = trim($id);
        $id = base64_decode($id);
        $oldData 		   =  $request->old();
        $data 	 = sms_student_marks::findOrFail($id);
        if(!empty($oldData)){
            $data->student_id 		= 	$oldData['student_id'];
            $data->term 		= 	$oldData['term'];
            $data->maths_mark 		= 	$oldData['maths_mark'];
            $data->science_mark 		= 	$oldData['science_mark'];
            $data->history_mark 		= 	$oldData['history_mark'];
        }
        $getStudents = sms_student_details::get();
        return view('marks/edit', compact('data','encId','getStudents'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\sms_student_marks  $sms_student_marks
     * @return \Illuminate\Http\Response
     */
    public function update($id,Request $request, sms_student_marks $sms_student_marks)
    {
        $encId = trim($id);
        $id = base64_decode($id);
        $postData =  $request->all();
        $request->validate([
            'student_id' 		=> 'required',
            'student_id' 		=> 'unique:sms_student_marks,student_id,'.$id,
            'term' 		=> 'required',
            'maths_mark' => 'required',
            'science_mark' => 'required',
            'history_mark' => 'required',
        ], [
            'student_id.required' 		 => 'Please select any student.',
            'student_id.unique' 		 => 'Chosen student already selected.',
            'term.required' 	 => 'Please select any term.',
            'maths_mark.required' => 'Please enter maths mark.',
            'science_mark.required' => 'Please enter science mark.',
            'history_mark.required' => 'Please enter history mark.',
        ]);

        $marks = sms_student_marks::where('id', $id)->first();

        $marks->student_id 		= $postData['student_id'];
        $marks->term 		= $postData['term'];
        $marks->maths_mark 		= $postData['maths_mark'];
        $marks->science_mark 		= $postData['science_mark'];
        $marks->history_mark 		= $postData['history_mark'];
        $marks->modified_date 		= date('Y-m-d h:i:s');

        if($marks->save()){
			\Session::flash('success', 'Marks created successfully.' );
		}else{
			\Session::flash('failure', 'Unable to create mark.' );
		}		
		return redirect(url('/marks'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\sms_student_marks  $sms_student_marks
     * @return \Illuminate\Http\Response
     */
    public function destroy($id,sms_student_marks $sms_student_marks)
    {
        $id = base64_decode($id);
        sms_student_marks::where('id',$id)->delete();
        \Session::flash('success', 'Marks deleted successfully.' );
        return redirect(url('/marks'));
    }
}
