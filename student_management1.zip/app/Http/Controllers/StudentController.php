<?php

namespace App\Http\Controllers;

use App\Models\sms_student_details;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $getStudents = sms_student_details::get();
        return view('student/index',compact('getStudents'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('student/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $postData = $request->all();
        $request->validate([
            'student_name' 		=> 'required',
            'age' 		=> 'required',
            'reporting_teacher' => 'required',
        ], [
            'student_name.required' 		 => 'Please enter student name.',
            'age.required' 	 => 'Please enter an age.',
            'reporting_teacher.required' => 'Please select teacher.',
        ]);

        $student = new sms_student_details;

        $student->student_name 		= $postData['student_name'];
        $student->student_age 		= $postData['age'];
        $student->gender 		= $postData['gender'];
        $student->reporting_teacher 		= $postData['reporting_teacher'];
        $student->created_date 		= date('Y-m-d h:i:s');
        $student->timestamps = false;

        if($student->save()){
			\Session::flash('success', 'Student created successfully.' );
		}else{
			\Session::flash('failure', 'Unable to create student.' );
		}		
		return redirect(url('/'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\sms_student_details  $sms_student_details
     * @return \Illuminate\Http\Response
     */
    public function show(sms_student_details $sms_student_details)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\sms_student_details  $sms_student_details
     * @return \Illuminate\Http\Response
     */
    public function edit($id,sms_student_details $sms_student_details,Request $request)
    {
        $encId = trim($id);
        $id = base64_decode($id);
        $oldData 		   =  $request->old();
        $data 	 = sms_student_details::findOrFail($id);
        if(!empty($oldData)){
            $data->student_name 		= 	$oldData['student_name'];
            $data->age 		= 	$oldData['age'];
            $data->gender 		= 	$oldData['gender'];
            $data->reporting_teacher 		= 	$oldData['reporting_teacher'];
        } else {
            $data->age = $data->student_age;
        }
        return view('student/edit', compact('data','encId'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\sms_student_details  $sms_student_details
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $encId = trim($id);
        $id = base64_decode($id);
        $postData =  $request->all();
        $request->validate([
            'student_name' 		=> 'required',
            'age' 		=> 'required',
            'reporting_teacher' => 'required',
        ], [
            'student_name.required' 		 => 'Please enter student name.',
            'age.required' 	 => 'Please enter an age.',
            'reporting_teacher.required' => 'Please select teacher.',
        ]);

        $student 	  = sms_student_details::where('id', $id)->first();

        $student->student_name 		= $postData['student_name'];
        $student->student_age 		= $postData['age'];
        $student->gender 		= $postData['gender'];
        $student->reporting_teacher 		= $postData['reporting_teacher'];
        $student->timestamps = false;

        if($student->save()){
			\Session::flash('success', 'Student created successfully.' );
		}else{
			\Session::flash('failure', 'Unable to create student.' );
		}		
		return redirect(url('/'));


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\sms_student_details  $sms_student_details
     * @return \Illuminate\Http\Response
     */
    public function destroy($id,sms_student_details $sms_student_details)
    {
        $id = base64_decode($id);
        sms_student_details::where('id',$id)->delete();
        \Session::flash('success', 'Student deleted successfully.' );
        return redirect(url('/'));
    }
}
