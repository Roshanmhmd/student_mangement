/* 

Project Name : Studernt Management
Php laravel framework

*/

jQuery(document).ready(function($) {
	
	// Student module
	$('#studentTable').DataTable({
        "dom": '<"datatableheader"fl>rt<"datatablefooter"ip><"clear">',
        "language": {
            "emptyTable": "No matching records found"
        }
    });
	
	$('body').on('click','.delete_student',function(e){
		$('#openDeleteModal').modal('show');
		var dataVal = $(this).attr('data-id');
		var currentUrl = $('#deleteStudent').attr('data-url');
		$('#deleteStudent').attr('action',currentUrl+'/'+dataVal);
		
	});
	
	// marks module
	
	$('body').on('click','.delete_marks',function(e){
		$('#openDeleteModal').modal('show');
		var dataVal = $(this).attr('data-id');
		var currentUrl = $('#deleteStudent').attr('data-url');
		$('#deleteStudent').attr('action',currentUrl+'/'+dataVal);
		
	});
	
});